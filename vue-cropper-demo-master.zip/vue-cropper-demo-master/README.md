
## vue-cropper 裁剪图片的基本原理
<p><a href="http://www.cnblogs.com/tugenhua0707/p/8859291.html" target="_blank">查看裁剪图片的基本原理</a></p>