
import cropper from './vue-cropper';
module.exports = cropper;